
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Instagram, Linkedin } from "lucide-react";
import { motion } from "framer-motion";

const Portfolio = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex flex-col items-center py-12">
      <motion.div className="max-w-4xl w-full p-8 bg-white rounded-2xl shadow-2xl" initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
        <div className="text-center mb-8">
          <motion.h1 className="text-5xl font-extrabold text-gray-800" initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ duration: 0.6 }}>
            Tegar Nugraha
          </motion.h1>
          <motion.p className="text-lg text-gray-600 mt-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
            Web Developer | Minecraft Server Owner | TNI AD Enthusiast
          </motion.p>
        </div>
        <Card className="mb-8">
          <CardContent>
            <h2 className="text-2xl font-semibold text-gray-700">About Me</h2>
            <p className="mt-2 text-gray-600">
              Halo! Nama gue Tegar, seorang pengembang web yang juga punya server Minecraft bernama Mineflew. Lagi nyiapin diri buat jadi Bintara TNI AD. Suka explore teknologi baru dan gaming.
            </p>
          </CardContent>
        </Card>
        <Card className="mb-8">
          <CardContent>
            <h2 className="text-2xl font-semibold text-gray-700">Projects</h2>
            <ul className="mt-2 text-gray-600 list-disc pl-6">
              <li>Mineflew - Minecraft Server Hosting</li>
              <li>Fanfic "Jika Mikasa Berkata Jujur" - Alternate Ending AoT</li>
              <li>Web Hosting Service (In Progress)</li>
            </ul>
          </CardContent>
        </Card>
        <Card className="mb-8">
          <CardContent>
            <h2 className="text-2xl font-semibold text-gray-700">Contact</h2>
            <div className="flex gap-4 mt-4">
              <Button variant="outline" as="a" href="https://github.com/7egarnugraha" target="_blank"><Github className="mr-2" /> Github</Button>
              <Button variant="outline" as="a" href="https://instagram.com/7egarnugraha" target="_blank"><Instagram className="mr-2" /> Instagram</Button>
              <Button variant="outline" as="a" href="https://linkedin.com/in/tegar-nugraha" target="_blank"><Linkedin className="mr-2" /> LinkedIn</Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default Portfolio;
